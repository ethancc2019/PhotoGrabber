import urllib.request
import webbrowser

import requests

espnPlayers = {}
jaarsPlayer = {}
validPhotosUrl = []
fileHandle = open("file.txt", "w")

"""
Function takes a file(in a specific format) and adds them to a dictionary for ESPN players and their IDs
"""
with open("MASTERPLAYERS(ESPN).txt") as f:
    for line in f:
        splitValue = line.split(",")
        espnPlayers[splitValue[0]] = splitValue[1]

        # reset values
        splitValue = ""

f.close()
"""
Function takes a file(in a specific format) and adds them to a dictionary for JAARS players and their IDs
"""
with open("MasterPlayerJaars") as f:
    for line in f:
        splitValue = line.split(",")
        jaarsPlayer[splitValue[0]] = splitValue[1]

        # reset values
        splitValue = ""

numeOfPlayers = 0
f.close()

"""
Function to find the current player in ESPN dictionary, find it in JAARS dictionary, check url for valid headshot, 
and download the image.
For now we will write them to a file for later use 
"""
f = open("ValidHeadshots.txt", "w+")
for k1, v1 in espnPlayers.items():
    if k1 in jaarsPlayer:
        tempJaarsId = jaarsPlayer[k1]
        jaarsIdStrip = tempJaarsId.split("\n")

        tempEspnId = v1
        espnPlayersIdStrip = v1.split("\n")
        url = "http://a.espncdn.com/combiner/i?img=/i/headshots/college-football/players/full/" + str(
            espnPlayersIdStrip[0]) + ".png"
        check = requests.get(url)
        if check.status_code != 404:
            print("Player: " + k1 + " has valid head shot")

            numeOfPlayers += 1
            # webbrowser.open(urlTemp)
            filePath = "C:\\users\ecollins\Work Folders\Desktop\CollegeTransparentHeadshots\\ " + str(
                jaarsIdStrip[0]) + ".png"

            f.write(k1 + " => " + url + "\n")



print("Valid # of headshots" + str(numeOfPlayers))
print("DONE!")

