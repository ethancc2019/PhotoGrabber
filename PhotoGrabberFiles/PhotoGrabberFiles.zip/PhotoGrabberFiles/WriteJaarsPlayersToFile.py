import pyodbc

connection = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                      "Server=warroom.stl.nfl.net;"
                      "Database=RadarDB;"
                      "Trusted_Connection=yes;")
cursor = connection.cursor()
cursor.execute("SELECT ISNULL(FootballName, FirstName)FirstName , Lastname, MasterPlayerID from POBase() where DraftYear > 2018")

results = cursor.fetchall()
length = len(results)
f = open("MasterPlayerJaars", "w")
for i in range(length):
    f.write(str(results[i][0]) + " " +str(results[i][1]) + "," + str(results[i][2]) + "\n")

cursor.close()
connection.close()